<?php // $Id: defaults.php,v 1.11.2.1 2006/05/13 17:04:11 gustav_delius Exp $

// This file is generally only included from upgrade_activity_modules()
// It defines default values for any important configuration variables

   $defaults = array (
       'mail_maxbytes' => 5242880
    );

?>
