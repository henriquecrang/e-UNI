<?PHP

function mail_upgrade($oldversion) {
/// This function does anything necessary to upgrade 
/// older versions to match current functionality 

   
   return true;
}

?>
